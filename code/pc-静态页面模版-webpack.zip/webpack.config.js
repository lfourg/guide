const webpack = require('webpack');
const path = require('path');
const fs = require('fs');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const OpenBrowserPlugin = require('open-browser-webpack-plugin');
const srcDir = path.resolve(process.cwd(), 'src');
module.exports = {
    cache: true,
    entry: getEntry(),
    output: {
        path: path.join(__dirname, "dist/"),
        publicPath: "/",
        filename: "js/[name].js"
    },
    module: {
        rules: [{
                test: /\.pug$/,
                use: [{
                    loader: 'pug-loader'
                }]
            }, {
                test: /\.css$/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: ["css-loader", "postcss-loader"]
                })
            }, {
                test: /\.js$/,
                exclude: /(node_modules)/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['env']
                    }
                }
            }, {
                test: /\.(png|gif|jpg|jpeg|bmp)$/i,
                exclude: /(node_modules)/,
                loader: 'url-loader?limit=5000'
            }, // 限制大小5kb
            {
                test: /\.(png|woff|woff2|svg|ttf|eot)($|\?)/i,
                exclude: /(node_modules)/,
                loader: 'url-loader?limit=5000'
            }
        ]
    },
    plugins: [
        // 热加载插件
        new webpack.HotModuleReplacementPlugin(),
        // 打开浏览器
        new OpenBrowserPlugin({
            url: 'http://localhost:8080'
        }),
        new ExtractTextPlugin({
            // filename: `css/[name].[hash:7].css`,
            filename: `css/[name].css`,
            allChunks: true
        }),
    ].concat(tmplEntry()),
    devServer: {
        noInfo: true,
        contentBase: "/", //本地服务器所加载的页面所在的目录
        historyApiFallback: true, //不跳转
        inline: true, //实时刷新
        hot: true // 使用热加载插件 HotModuleReplacementPlugin
    }
};




//获取多页面的每个入口文件，用于配置中的entry
function getEntry() {
    var jsPath = path.resolve(srcDir, 'js');
    var dirs = fs.readdirSync(jsPath);
    var arr = []
    var matchs = [],
        files = {};
    dirs.find(function(v, i, a) {
        if (v === '.DS_Store') {
            a.splice(i, 1)
        }
    })
    dirs.forEach(function(item) {
        var cdirs = fs.readdirSync(path.resolve(srcDir, `js/${item}`));
        cdirs.forEach(function(i) {
            matchs = i.match(/(.+)\.js$/);
            if (matchs) {
                files[item + "_" + matchs[1]] = path.resolve(srcDir, `js/${item}`, i);
            }
        })

    });
    return files;
}
//获取多页面的每个html入口文件，用于配置中的HtmlWebpackPlugin
function tmplEntry() {
    var jsPath = path.resolve(srcDir, 'html');
    var dirs = fs.readdirSync(jsPath);
    var matchs = [],
        files = [];
    dirs.forEach(function(v, i, a) {
        if (v === '.DS_Store' || v === 'components') {
            a.splice(i, 1)
        }
    })
    dirs.forEach(function(item) {
        var cdirs = fs.readdirSync(path.resolve(srcDir, `html/${item}`));
        cdirs.forEach(function(i) {
            matchs = i.match(/(.+)\.pug$/);
            var chunks = item + "_" + i.replace('.pug', "")
            if (matchs) {
                files.push(new HtmlWebpackPlugin({
                    template: path.resolve(srcDir, `html/${item}`, i),
                    filename: `html/${item}/${i.replace('.pug','')}.html`,
                    chunks: [chunks]
                }))
            }
        })
    });
    return files;
}
