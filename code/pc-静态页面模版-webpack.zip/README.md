>  本项目是基于webpack实现pc端多页面模版

###

### 项目技术架构
***
*  webpack
*  pug
*  webpack-dev-server
***


###安装
***
```
通过`npm`安装本地服务第三方依赖模块(需要已安装[Node.js](https://nodejs.org/))

```
npm install
```
启动服务(http://localhost:8080)

```
npm run dev
```

###目录结构
***
<pre>

</pre>

###实现的功能
***
* 图片压缩
* 支持es6
* 支持html include
* 支持less
* 支持自动追加前缀
* 浏览器实时刷新
* 等等





