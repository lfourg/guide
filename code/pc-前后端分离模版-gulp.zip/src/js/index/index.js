import '../common/c.js'

console.log(2222)