
document.documentElement.style.fontSize = document.documentElement.clientWidth*2*100/750 + 'px';